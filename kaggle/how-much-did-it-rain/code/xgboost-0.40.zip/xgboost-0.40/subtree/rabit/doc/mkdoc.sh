#!/bin/bash
cd ../include
doxygen ../doc/Doxyfile 
cd ../doc
